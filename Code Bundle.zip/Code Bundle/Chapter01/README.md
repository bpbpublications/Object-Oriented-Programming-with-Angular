# Typescript code

## Setup

1. Download and install Node.js
2. Compile program by running `tsc` command e.g.
```sh
tsc --target ES5 --experimentalDecorators decorators.ts
```
3. Run program using `node` command e.g.
```bash
node decorators.js
```