
  export class Math {
    static Square(input: number): number {
      return input * input;
    }
  }

  const answer = Math.Square(5);
  console.log(answer);
