export class Bottle {
  capacity: number | string;
  color: string;
}

function getWebResponse(param: string): string | JSON | number {
  return "some web response";
}