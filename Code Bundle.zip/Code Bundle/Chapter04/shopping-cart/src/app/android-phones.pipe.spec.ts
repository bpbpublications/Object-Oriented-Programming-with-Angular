import { AndroidPhonesPipe } from './android-phones.pipe';

describe('AndroidPhonesPipe', () => {
  it('create an instance', () => {
    const pipe = new AndroidPhonesPipe();
    expect(pipe).toBeTruthy();
  });
});
