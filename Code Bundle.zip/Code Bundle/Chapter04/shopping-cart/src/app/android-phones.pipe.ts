import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'androidPhones',
  pure: false
})
export class AndroidPhonesPipe implements PipeTransform {
  transform(mobiles: string[], args?: any): any {
    return mobiles.filter(x => !x.startsWith('iPhone'));
  }
}
