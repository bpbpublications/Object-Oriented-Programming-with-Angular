import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Shopping Cart';
  totalItems: number;
  customerName: string;
  quantity: number;

  allItems = [
    'iPhone XS',
    'Samsung Note 9',
    'Pixel 3 XL',
    'OnePlus 6T',
    'Sony Xperia 10 Plus'
  ];

  selectedItem: string;
  cart = [];

  addToCart() {
    this.cart.push(this.selectedItem);
    // alert(`${this.selectedItem} is added to cart!`);
  }

  updateSelection(value: string) {
    this.selectedItem = value;
  }
}

function gobalFunction() {
  alert('I am global function');
}

