import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppComponent } from './app.component';
import { PrefixPipe } from './prefix.pipe';
import { AndroidPhonesPipe } from './android-phones.pipe';

@NgModule({
  declarations: [AppComponent, PrefixPipe, AndroidPhonesPipe],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [
    PrefixPipe,
    AndroidPhonesPipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
