import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'prefix'
})
export class PrefixPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (value) {
      return args? 'Mobile: ' + value :  'Handy: ' + value;;
    }
    return '';
  }
}
