    import { Component, Inject } from '@angular/core';
    import { Vehicles } from "./vehicles";
    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
    export class AppComponent {
        title = 'automobile-demo';

        constructor(@Inject(Vehicles)private vehicles: Array<string>) {
        }

        ngOnInit(){
            console.log(this.vehicles);
        }
    }
