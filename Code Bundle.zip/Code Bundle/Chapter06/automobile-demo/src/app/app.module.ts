    import { BrowserModule } from '@angular/platform-browser';
    import { NgModule } from '@angular/core';
    import { HttpClientModule } from "@angular/common/http";

    import { AppRoutingModule } from './app-routing.module';
    import { AppComponent } from './app.component';
    import { Vehicles } from './vehicles';
    import { Cars } from './cars';
    import { Trucks } from './trucks';

    @NgModule({
        declarations: [
            AppComponent
        ],
        imports: [
            BrowserModule,
            AppRoutingModule,
            HttpClientModule
        ],
        providers: [
            {
                provide: Vehicles, useValue: Trucks
            }
        ],
        bootstrap: [AppComponent]
    })
    export class AppModule { }

