import { Component, OnInit } from '@angular/core';
import { EngineService } from '../engine.service';
import { Engine } from '../engine';
import { DataService } from '../data.service';
import { MockDataService } from '../mock-data.service';
import { CarService } from './car.service';
import { IDataService } from '../idata.service';

@Component({
    selector: 'app-car',
    templateUrl: './car.component.html',
    styleUrls: ['./car.component.css'],
    providers: [CarService]
})
export class CarComponent implements OnInit {

    model: string;
    engine: Engine;

    constructor(private engineService: EngineService,
                private dataService: IDataService,
                private carService: CarService) { }

    ngOnInit() {
        this.model = 'Car Model';
        this.engine = this.engineService.getEngine();

        this.dataService.getPosts().subscribe(posts => {
            console.log(posts);
        });

        console.log(`Fuel Type: ${this.carService.fuelType}`);
    }

}
