    import { NgModule } from '@angular/core';
    import { CommonModule } from '@angular/common';

    import { CarRoutingModule } from './car-routing.module';
    import { CarComponent } from './car.component';
    import { MockDataService } from '../mock-data.service';
    import { IDataService } from '../idata.service';
    import { DataService } from '../data.service';


    @NgModule({
        declarations: [CarComponent],
        imports: [
            CommonModule,
            CarRoutingModule
        ],
        providers: [
            { provide: IDataService, useClass: DataService }
        ]
    })
    export class CarModule { }
