    import { Injectable } from '@angular/core';

    @Injectable()
    export class CarService {

        fuelType: string = 'Petrol';

        constructor() {
            console.log('CarService initialized....');
        }
    }
