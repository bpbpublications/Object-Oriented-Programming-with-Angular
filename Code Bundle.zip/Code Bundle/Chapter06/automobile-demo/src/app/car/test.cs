    IUnityContainer container = new UnityContainer();
    container.RegisterType<IDataService, DataService>("DataService");
    container.RegisterType<IDataService, MockDataService>("MockDataService");

    IDataService service = container.Resolve<IDataService>("DataService");
    service.GetPosts();

        var container = new UnityContainer();
    ICar audi = new Audi();
    container.RegisterInstance<ICar>(audi);