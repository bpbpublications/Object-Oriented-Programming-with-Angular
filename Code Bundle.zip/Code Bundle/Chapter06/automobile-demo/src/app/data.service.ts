import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IDataService } from './idata.service';

@Injectable()
export class DataService implements IDataService{

    constructor(private httpClient: HttpClient) { }

    getPosts(): Observable<any> {
        const url = 'https://my-json-server.typicode.com/typicode/demo/posts';
        return this.httpClient.get(url);
    }
}
