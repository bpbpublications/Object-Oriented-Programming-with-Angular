import { Injectable } from '@angular/core';
import { Engine } from './engine';

@Injectable({
    providedIn: 'root'
})
export class EngineService {
    private _engine: Engine;
    static instanceCount = 0;

    constructor() {
        EngineService.instanceCount++;
        console.log(`EngineService instance created. Instance Count = ${EngineService.instanceCount}`);
        this._engine = new Engine("CarEngine-1", 3000);
    }

    public getEngine(): Engine {
        return this._engine;
    }
}
