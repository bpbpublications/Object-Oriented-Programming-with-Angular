import { Engine } from './engine';

describe('Engine', () => {
  it('should create an instance', () => {
    expect(new Engine()).toBeTruthy();
  });
});
