export class Engine {

    private _model: string;
    public get model(): string {
        return this._model;
    }

    private _horsePower: number;
    public get horsePower(): number {
        return this._horsePower;
    }

    constructor(model: string, horsePower: number) {
        this._model = model;
        this._horsePower = horsePower;
    }
}
