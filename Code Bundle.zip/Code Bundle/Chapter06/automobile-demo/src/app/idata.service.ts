    import { Observable } from 'rxjs';

    export abstract class IDataService {
        abstract getPosts(): Observable<any>;
    }