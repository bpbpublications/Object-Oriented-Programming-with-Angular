import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IDataService } from "./idata.service";

    @Injectable()
    export class MockDataService implements IDataService {
    MOCK_POSTS = [
        {
            "id": 1,
            "title": "Mock Post 1"
        },
        {
            "id": 2,
            "title": "Mock Post 2"
        },
        {
            "id": 3,
            "title": "Mock Post 3"
        }
    ];
        getPosts(): Observable<any> {
            return of(this.MOCK_POSTS);
        }
}
