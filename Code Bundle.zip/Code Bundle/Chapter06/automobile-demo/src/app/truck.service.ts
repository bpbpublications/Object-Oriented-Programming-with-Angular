
    export function TruckServiceFactory(stroke: number, capacity: number) {
        return (): TruckService => {
            return new TruckService(stroke, capacity);
        }
    }

    export class TruckService {

        private _stroke: number;
        private _capacity: number;

        constructor(stroke: number, capacity: number) {
            this._stroke = stroke;
            this._capacity = capacity;
        }

        getStroke() {
            return this._stroke;
        }

        getCapacity() {
            return this._capacity;
        }
    }
