import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TruckSuvComponent } from './truck-suv.component';

const routes: Routes = [{ path: '', component: TruckSuvComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TruckSuvRoutingModule { }
