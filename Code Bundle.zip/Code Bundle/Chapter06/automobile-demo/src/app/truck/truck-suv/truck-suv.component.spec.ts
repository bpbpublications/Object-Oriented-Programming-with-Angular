import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TruckSuvComponent } from './truck-suv.component';

describe('TruckSuvComponent', () => {
  let component: TruckSuvComponent;
  let fixture: ComponentFixture<TruckSuvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TruckSuvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TruckSuvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
