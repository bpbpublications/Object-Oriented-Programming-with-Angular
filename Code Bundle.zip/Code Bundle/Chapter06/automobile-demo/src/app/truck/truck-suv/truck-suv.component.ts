    import { Component, OnInit } from '@angular/core';
    import { EngineService } from 'src/app/engine.service';

    @Component({
    selector: 'app-truck-suv',
    templateUrl: './truck-suv.component.html',
    styleUrls: ['./truck-suv.component.css']
    })
    export class TruckSuvComponent implements OnInit {

    constructor(private engineService: EngineService) { }

    ngOnInit() {
    }

    }
