    import { NgModule } from '@angular/core';
    import { CommonModule } from '@angular/common';

    import { TruckSuvRoutingModule } from './truck-suv-routing.module';
    import { TruckSuvComponent } from './truck-suv.component';
    import { EngineService } from 'src/app/engine.service';


    @NgModule({
    declarations: [TruckSuvComponent],
    imports: [
        CommonModule,
        TruckSuvRoutingModule
    ],
    providers: [EngineService]
    })
    export class TruckSuvModule { }
