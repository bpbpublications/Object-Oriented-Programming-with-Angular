    import { Component, OnInit } from '@angular/core';
    import { EngineService } from '../engine.service';
    import { Engine } from '../engine';
import { TruckService } from '../truck.service';

    @Component({
        selector: 'app-truck',
        templateUrl: './truck.component.html',
        styleUrls: ['./truck.component.css']
    })
    export class TruckComponent implements OnInit {
        model: string;
        engine: Engine;

        stroke: number;
        capacity: number;

        constructor(private engineService: EngineService, 
            private truckService: TruckService) { }

        ngOnInit() {
            this.model = "Truck Model";
            this.engine = this.engineService.getEngine();

            this.stroke = this.truckService.getStroke();
            this.capacity = this.truckService.getCapacity();
        }
    }