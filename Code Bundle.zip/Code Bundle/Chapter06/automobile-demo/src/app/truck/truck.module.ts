    import { NgModule } from '@angular/core';
    import { CommonModule } from '@angular/common';

    import { TruckRoutingModule } from './truck-routing.module';
    import { TruckComponent } from './truck.component';
    import { TruckService, TruckServiceFactory } from '../truck.service';


    @NgModule({
        declarations: [TruckComponent],
        imports: [
            CommonModule,
            TruckRoutingModule
        ],
        providers: [
            {
                provide: TruckService, useFactory: TruckServiceFactory(62, 449)
            }
        ]
    })
    export class TruckModule { }
