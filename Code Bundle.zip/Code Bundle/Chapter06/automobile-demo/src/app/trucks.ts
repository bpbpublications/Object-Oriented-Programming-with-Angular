    export const Trucks = [
        'Truck 1',
        'Truck 2',
        'Truck 3',
        'Truck 4',
        'Truck 5'
    ]