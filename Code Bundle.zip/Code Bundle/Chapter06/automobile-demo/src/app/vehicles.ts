    import { InjectionToken } from '@angular/core';
    export const Vehicles = new InjectionToken<Array<string>>('Vehicles');
