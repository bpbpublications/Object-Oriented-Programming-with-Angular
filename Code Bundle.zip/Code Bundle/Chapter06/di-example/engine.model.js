"use strict";
exports.__esModule = true;
var Engine = /** @class */ (function () {
    function Engine() {
    }
    return Engine;
}());
exports.Engine = Engine;
