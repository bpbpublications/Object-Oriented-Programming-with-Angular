export class Engine {
    model: string;
    horsePower: number;

    constructor(_horsePower:number){
        this.horsePower = _horsePower;
    }
}