import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TemplateLoginFormModule } from './template-login-form/template-login-form.module';
import { InvalidUsernameDirective } from './invalid-username.directive';
import { ReactiveLoginFormModule } from './reactive-login-form/reactive-login-form.module';

@NgModule({
    declarations: [
        AppComponent],
    imports: [
        BrowserModule,
        TemplateLoginFormModule,
        ReactiveLoginFormModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
