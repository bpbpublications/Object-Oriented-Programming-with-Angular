import { AuthModel } from './auth-model';

describe('AuthModel', () => {
  it('should create an instance', () => {
    expect(new AuthModel()).toBeTruthy();
  });
});
