    export class AuthModel {
        username = '';
        password = '';
    }
