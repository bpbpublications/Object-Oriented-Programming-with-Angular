import { InvalidUsernameDirective } from './invalid-username.directive';

describe('InvalidUsernameDirective', () => {
  it('should create an instance', () => {
    const directive = new InvalidUsernameDirective();
    expect(directive).toBeTruthy();
  });
});
