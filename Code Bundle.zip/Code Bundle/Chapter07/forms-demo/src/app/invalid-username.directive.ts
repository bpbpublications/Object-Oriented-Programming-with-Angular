    import { Directive, Input } from '@angular/core';
    import { NG_VALIDATORS, Validator, AbstractControl, ValidatorFn } from '@angular/forms';

    export function invalidUsernameValidator(invalidCharacter: string): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const invalid = control.value.startsWith(invalidCharacter);
            return invalid ? { 'invalidCharacter': { value: control.value } } : null;
        };
    }

    @Directive({
        selector: '[appInvalidUsername]',
        providers: [
            {
                provide: NG_VALIDATORS,
                useExisting: InvalidUsernameDirective,
                multi: true
            }]
    })
    export class InvalidUsernameDirective implements Validator {

        @Input('appInvalidUsername') invalidCharacter = "@";
        
        constructor() { }

        validate(control: AbstractControl) {
            console.log(this.invalidCharacter);
            console.log(control.value);

            return control.value && this.invalidCharacter ? invalidUsernameValidator(this.invalidCharacter)(control) : null;
        }

    }
