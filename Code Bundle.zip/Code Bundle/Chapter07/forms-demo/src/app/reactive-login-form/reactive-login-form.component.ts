import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthModel } from '../auth-model';
import { invalidUsernameValidator } from '../invalid-username.directive';

@Component({
    selector: 'app-reactive-login-form',
    templateUrl: './reactive-login-form.component.html',
    styleUrls: ['./reactive-login-form.component.css']
})
export class ReactiveLoginFormComponent implements OnInit {

    loginForm: FormGroup;
    authModel: AuthModel;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.authModel = new AuthModel();
        this.loginForm = this.formBuilder.group({
            "username": new FormControl('', [Validators.required, invalidUsernameValidator("@")]),
            "password": ['', Validators.required]
        });
    }

    onSubmit() {
        console.log(this.loginForm.value);
        this.authModel.username = this.loginForm.controls["username"].value;
        this.authModel.password = this.loginForm.controls["password"].value;
        alert(this.authModel.username + ' ' + this.authModel.password);
    }
}
