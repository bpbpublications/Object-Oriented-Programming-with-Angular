import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveLoginFormComponent } from './reactive-login-form.component';
import { ReactiveFormsModule } from "@angular/forms";


@NgModule({
    declarations: [ReactiveLoginFormComponent],
    exports: [ReactiveLoginFormComponent],
    imports: [
        CommonModule,
        ReactiveFormsModule
    ]
})
export class ReactiveLoginFormModule { }
