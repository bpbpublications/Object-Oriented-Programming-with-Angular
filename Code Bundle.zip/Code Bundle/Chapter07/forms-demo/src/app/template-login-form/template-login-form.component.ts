import { Component, OnInit } from '@angular/core';
    import { AuthModel } from '../auth-model';

    @Component({
        selector: 'app-template-login-form',
        templateUrl: './template-login-form.component.html',
        styleUrls: ['./template-login-form.component.css']
    })
    export class TemplateLoginFormComponent implements OnInit {

        authModel: AuthModel;

        constructor() { }

        ngOnInit() {
            this.authModel = new AuthModel();
        }

        onSubmit() {
            alert(this.authModel.username + ' ' + this.authModel.password);
        }
    }
