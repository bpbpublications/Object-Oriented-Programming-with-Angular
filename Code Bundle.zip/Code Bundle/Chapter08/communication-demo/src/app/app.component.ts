    import { Component, OnInit, ViewChild } from '@angular/core';
    import { ColorDemoComponent } from './color-demo/color-demo.component';
    import { DataService } from './data.service';

    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
    export class AppComponent implements OnInit {

        backgroundColor = '';

        newColor = '';

        // @ViewChild(ColorDemoComponent, { static: false }) private childComponent: ColorDemoComponent;

        constructor(private dataService: DataService) {
        }

        ngOnInit() {
            this.newColor = 'gray';

            this.dataService.parentColorChanged$.subscribe((newColor: string) => {
                this.newColor = newColor;
            });

        }

        onOutputColorChanged(newColor: string) {
            this.newColor = newColor;
        }

        setNewColor(newColor: string) {
            // this.childComponent.setNewColor(newColor);
            // this.dataService.childColor = newColor;

            this.dataService.updateChildColor(newColor);

        }

        showColorName() {
            // this.childComponent.showColorName();
            // alert(this.parentColor);
        }
    }
