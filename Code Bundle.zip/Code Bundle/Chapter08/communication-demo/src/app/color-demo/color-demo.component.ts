import { Component, OnInit, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { DataService } from '../data.service';

@Component({
    selector: 'app-color-demo',
    templateUrl: './color-demo.component.html',
    styleUrls: ['./color-demo.component.css']
})
export class ColorDemoComponent implements OnInit {

    @Input('inputBGColor') inputColor = '';
    @Output() outputColorChanged = new EventEmitter<string>();

    newParentColor: string;

    constructor(private dataService: DataService) {

    }

    ngOnInit() {
        this.inputColor = 'gray';

        this.dataService.childColorChanged$.subscribe((newColor: string) => {
            this.inputColor = newColor;
        });

    }

    updateParent() {
        // this.outputColorChanged.emit(this.inputColor);
    }

    updateParentColor(newColor: string) {
        this.dataService.updateParentColor(newColor);
    }

    showColorName() {
        alert(this.inputColor);
    }

    setNewColor(newColor: string) {
        this.inputColor = newColor;
    }
}
