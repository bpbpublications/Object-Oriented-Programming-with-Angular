    import { Injectable } from '@angular/core';
    import { Subject, Observable } from 'rxjs';

    @Injectable({
        providedIn: 'root'
    })
    export class DataService {

        private parentColorChangedSource: Subject<string>;
        private childColorChangedSource: Subject<string>;

        parentColorChanged$: Observable<string>;
        childColorChanged$: Observable<string>;

        constructor() {
            this.parentColorChangedSource = new Subject<string>();
            this.parentColorChanged$ = this.parentColorChangedSource.asObservable();

            this.childColorChangedSource = new Subject<string>();
            this.childColorChanged$ = this.childColorChangedSource.asObservable();
        }

        updateParentColor(newColor: string) {
            this.parentColorChangedSource.next(newColor);
        }

        updateChildColor(newColor: string) {
            this.childColorChangedSource.next(newColor);
        }
    }
