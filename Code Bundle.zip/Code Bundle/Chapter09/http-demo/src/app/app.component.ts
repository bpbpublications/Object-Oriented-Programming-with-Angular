    import { Component, OnInit } from '@angular/core';

    import { PostModel } from './post.model';
    import { PostsService } from './posts.service';
    import { HttpErrorResponse } from '@angular/common/http';
    import { DataService } from './data.service';

    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
    export class AppComponent implements OnInit {
        title = 'Http Demo';

        posts: Array<PostModel> = [];

        postCount = 0;

        newPost: PostModel;

        searchUserId = 0;

        constructor(private postsService: DataService) {
        }

        ngOnInit() {
            this.newPost = new PostModel();

            this.postsService.getPosts().subscribe(data => {
                this.posts = data;
                this.postCount = data.length;
                console.log(this.posts);
            },
                (errors: HttpErrorResponse) => {
                    console.error(`Status: ${errors.status}`);
                    console.error(`Status Text: ${errors.statusText}`);
                    console.error(`Message: ${errors.message}`);
                    // alert('Something went wrong!');
                }
            );

            // console.log(`Post count = ${this.postCount}`);

            // this.posts = await this.http.get<Array<PostModel>>(this.url).toPromise();
            // this.postCount = this.posts.length;
            // console.log(this.posts);

            // console.log(`Post count = ${this.postCount}`);
        }

        createPost(): void {
            this.newPost.userId = 52;
            this.postsService.createPost(this.newPost).subscribe(newPostData => {
                console.log(newPostData);
                alert('New post created!');
            });
        }

        udpatePost(): void {
            this.postsService.updatePost(this.newPost).subscribe(updatedPost => {
                console.log(updatedPost);
            });
        }

        deletePost(): void {
            this.postsService.deletePost(this.newPost.id).subscribe(response => {
                console.log(response);
                alert('Post deleted!');
            },
                errors => console.log(errors));
        }

        searchPost(): void {
            this.postsService.searchPost(this.searchUserId).subscribe(foundPost => {
                console.log(foundPost);
            });
        }
    }
