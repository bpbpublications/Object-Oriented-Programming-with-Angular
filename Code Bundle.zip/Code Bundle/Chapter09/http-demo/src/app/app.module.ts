    import { BrowserModule } from '@angular/platform-browser';
    import { NgModule } from '@angular/core';
    import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
    import { FormsModule } from '@angular/forms';

    import { AppRoutingModule } from './app-routing.module';
    import { AppComponent } from './app.component';
    import { DataService } from './data.service';
    import { PostsService } from './posts.service';
    import { MockPostsService } from './mock-posts.service';
    import { PostsInterceptor } from './posts-interceptor.service';

    @NgModule({
        declarations: [
            AppComponent
        ],
        imports: [
            BrowserModule,
            AppRoutingModule,
            HttpClientModule,
            FormsModule
        ],
        providers: [
            {
                provide: DataService,
                useClass: PostsService
            },
            { provide: HTTP_INTERCEPTORS, useClass: PostsInterceptor, multi: true },

        ],
        bootstrap: [AppComponent]
    })
    export class AppModule {

    }

