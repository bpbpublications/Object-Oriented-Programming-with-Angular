import { Observable } from 'rxjs';
import { PostModel } from './post.model';

export abstract class DataService {
    abstract getPosts(): Observable<Array<PostModel>>;
    abstract createPost(newPost: PostModel): Observable<PostModel>;
    abstract updatePost(modifiedPost: PostModel): Observable<PostModel>;
    abstract deletePost(postId: number);
    abstract searchPost(postId: number): Observable<Array<PostModel>>;
}
