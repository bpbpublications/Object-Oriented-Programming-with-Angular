import { TestBed } from '@angular/core/testing';

import { MockPostsService } from './mock-posts.service';

describe('MockPostsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MockPostsService = TestBed.get(MockPostsService);
    expect(service).toBeTruthy();
  });
});
