    import { Injectable } from '@angular/core';
    import { PostModel } from './post.model';
    import { Observable, of } from 'rxjs';
    import { DataService } from './data.service';

    export class MockPostsService implements DataService {

        mockPosts: Array<PostModel> = [];

        constructor() {
            let post = new PostModel();
            post.id = 1;
            post.userId = 1;
            post.title = 'Mock post 1';
            post.body = 'Mock body of post 1';
            this.mockPosts.push(post);

            post = new PostModel();
            post.id = 2;
            post.userId = 2;
            post.title = 'Mock post 2';
            post.body = 'Mock body of post 2';
            this.mockPosts.push(post);

            post = new PostModel();
            post.id = 3;
            post.userId = 3;
            post.title = 'Mock post 3';
            post.body = 'Mock body of post 3';
            this.mockPosts.push(post);

            post = new PostModel();
            post.id = 4;
            post.userId = 4;
            post.title = 'Mock post 4';
            post.body = 'Mock body of post 4';
            this.mockPosts.push(post);

            post = new PostModel();
            post.id = 5;
            post.userId = 5;
            post.title = 'Mock post 5';
            post.body = 'Mock body of post 5';
            this.mockPosts.push(post);
        }

        public getPosts(): Observable<Array<PostModel>> {
            return of(this.mockPosts);
        }
        public createPost(newPost: PostModel): Observable<PostModel> {
            return of(this.mockPosts[0]);
        }
        public updatePost(modifiedPost: PostModel): Observable<PostModel> {
            return of(this.mockPosts[0]);
        }
        public deletePost(postId: number) {
            return {};
        }
        public searchPost(postId: number): Observable<Array<PostModel>> {
            return of(this.mockPosts.filter(x => x.id === postId));
        }
    }
