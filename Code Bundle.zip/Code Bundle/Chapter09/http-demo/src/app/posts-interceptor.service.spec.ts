import { TestBed } from '@angular/core/testing';

import { PostsInterceptor } from './posts-interceptor.service';

describe('PostsInterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PostsInterceptor = TestBed.get(PostsInterceptor);
    expect(service).toBeTruthy();
  });
});
