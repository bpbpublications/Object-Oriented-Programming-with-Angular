    import { Injectable } from '@angular/core';
    import { Observable } from 'rxjs';
    import { retry } from 'rxjs/operators';
    import { HttpClient, HttpHeaders } from '@angular/common/http';

    import { PostModel } from './post.model';
    import { environment } from 'src/environments/environment';
    import { DataService } from './data.service';

    @Injectable({
        providedIn: 'root'
    })
    export class PostsService implements DataService {

        url = environment.baseUrl + '/posts';

        httpOptions: any;

        constructor(private http: HttpClient) {
            this.httpOptions = {
                headers: new HttpHeaders({
                    'Authorization': 'jwt-mock-token',
                    'My-Custom-Header': 'custom-header-value'
                })
            };
        }

        public getPosts(): Observable<Array<PostModel>> {
            return this.http.get<Array<PostModel>>(this.url,
                { headers: this.httpOptions.headers }).pipe(retry(5));
        }

        public createPost(newPost: PostModel): Observable<PostModel> {
            return this.http.post<PostModel>(this.url, newPost);
        }
        public updatePost(modifiedPost: PostModel): Observable<PostModel> {
            const postUrl = this.url + '/' + modifiedPost.id;
            return this.http.put<PostModel>(postUrl, modifiedPost);
        }
        public deletePost(postId: number) {
            const deleteUrl = this.url + `/${postId}`;
            return this.http.delete(deleteUrl);
        }
        public searchPost(postId: number): Observable<Array<PostModel>> {
            const searchPostUrl = this.url + `?userId=${postId}`;
            return this.http.get<Array<PostModel>>(searchPostUrl);
        }
    }
