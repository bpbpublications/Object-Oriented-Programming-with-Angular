import { TestBed, async, inject } from '@angular/core/testing';

import { CanDeactivateDashboardGuard } from './can-deactivate-dashboard.guard';

describe('CanDeactivateDashboardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CanDeactivateDashboardGuard]
    });
  });

  it('should ...', inject([CanDeactivateDashboardGuard], (guard: CanDeactivateDashboardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
