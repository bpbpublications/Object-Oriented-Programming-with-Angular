import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomPageNotFoundComponent } from './custom-page-not-found.component';

describe('CustomPageNotFoundComponent', () => {
  let component: CustomPageNotFoundComponent;
  let fixture: ComponentFixture<CustomPageNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomPageNotFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomPageNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
