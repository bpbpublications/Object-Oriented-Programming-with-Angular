import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-page-not-found',
  templateUrl: './custom-page-not-found.component.html',
  styleUrls: ['./custom-page-not-found.component.css']
})
export class CustomPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
