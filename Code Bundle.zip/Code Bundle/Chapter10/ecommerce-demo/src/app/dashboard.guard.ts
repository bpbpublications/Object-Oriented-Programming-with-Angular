    import { Injectable } from '@angular/core';
    import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
    import { DataService } from './data.service';

    @Injectable({
        providedIn: 'root'
    })
    export class CanActivateDashboardGuard implements CanActivate {

        constructor(private dataService: DataService, private router: Router) { }

        canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
            if (this.dataService.isLoggedIn) {
                return true;
            }
            this.router.navigateByUrl('/login');
        }
    }
