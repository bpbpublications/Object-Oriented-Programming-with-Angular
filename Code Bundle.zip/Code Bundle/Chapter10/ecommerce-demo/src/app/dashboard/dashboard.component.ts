    import { Component, OnInit } from '@angular/core';
    import { DataService } from '../data.service';
    import { AuthModel } from '../auth.model';

    @Component({
        selector: 'app-dashboard',
        templateUrl: './dashboard.component.html',
        styleUrls: ['./dashboard.component.css']
    })
    export class DashboardComponent implements OnInit {

        loggedInUser: AuthModel;
        constructor(private dataService: DataService) { }

        ngOnInit() {
            this.loggedInUser = this.dataService.loggedInUser;
        }

    }
