    import { Component, OnInit } from '@angular/core';
    import { ActivatedRoute } from '@angular/router';
    import { ProductModel, ProductsService } from 'src/app/products.service';

    @Component({
        selector: 'app-product-details',
        templateUrl: './product-details.component.html',
        styleUrls: ['./product-details.component.css']
    })
    export class ProductDetailsComponent implements OnInit {

        selectedProduct: ProductModel;

        constructor(private activatedRoute: ActivatedRoute,
            private productService: ProductsService) { }

        ngOnInit() {
            this.activatedRoute.data.subscribe((data: { selectedProduct: ProductModel }) => {
                this.selectedProduct = data.selectedProduct;
                console.log(this.selectedProduct);

            });
            // const productId = Number.parseInt(this.activatedRoute.snapshot.paramMap.get('product-id'));
            // this.selectedProduct = this.productService.getProduct(productId);
            // console.log(this.selectedProduct);

        }

    }
