import { Injectable } from '@angular/core';
import { AuthModel } from './auth.model';

@Injectable({
    providedIn: 'root'
})
export class DataService {

    public loggedInUser: AuthModel;

    // tslint:disable-next-line: variable-name
    private _isLoggedIn: boolean;

    public get isLoggedIn(): boolean {
        // return this.loggedInUser ? true : false;
        return window.localStorage.getItem('isLoggedIn') ? true : false;
    }

    constructor() { }

    signOut() {
        window.localStorage.removeItem('isLoggedIn');
        this.loggedInUser = null;
    }
}
