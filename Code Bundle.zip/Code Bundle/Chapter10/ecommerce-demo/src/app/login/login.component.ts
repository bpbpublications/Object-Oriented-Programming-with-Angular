import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthModel } from '../auth.model';
import { DataService } from '../data.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    authModel: AuthModel;

    constructor(private router: Router,
                private dataService: DataService) { }

    ngOnInit() {
        this.authModel = new AuthModel();
    }

    doLogin() {
        // TODO: check username and password
        // this.router.navigateByUrl('/dashboard');
        this.dataService.loggedInUser = this.authModel;
        window.localStorage.setItem('isLoggedIn', 'true');
        this.router.navigate(['dashboard']);
    }
}
