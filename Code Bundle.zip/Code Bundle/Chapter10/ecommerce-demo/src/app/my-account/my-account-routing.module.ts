    import { NgModule } from '@angular/core';
    import { Routes, RouterModule } from '@angular/router';

    import { MyAccountComponent } from './my-account.component';

    const routes: Routes = [
        {
            path: '',
            component: MyAccountComponent
        },
        {
            path: 'profile',
            loadChildren: () => import('./profile/profile.module')
                .then(m => m.ProfileModule)
        },
        {
            path: 'invoices',
            loadChildren: () => import('./invoices/invoices.module')
                .then(m => m.InvoicesModule)
        }
    ];

    @NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule]
    })
    export class MyAccountRoutingModule { }
