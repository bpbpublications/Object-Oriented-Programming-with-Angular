    import { Injectable } from '@angular/core';
    import { Resolve, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
    import { ProductModel, ProductsService } from './products.service';
    import { Observable, of, EMPTY } from 'rxjs';

    @Injectable({
        providedIn: 'root'
    })
    export class ProductDetailsResolverService implements Resolve<ProductModel> {

        constructor(private productService: ProductsService,
                    private router: Router) { }

        resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ProductModel> | Observable<never> {
            const productId = Number.parseInt(route.paramMap.get('product-id'), 10);

            const foundProduct = this.productService.getProduct(productId);
            if (foundProduct) {
                return of(foundProduct);
            } else {
                this.router.navigateByUrl('/dashboard/products');
                return EMPTY;
            }
        }
    }
