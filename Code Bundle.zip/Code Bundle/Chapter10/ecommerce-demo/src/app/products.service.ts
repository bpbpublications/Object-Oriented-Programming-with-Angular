    import { Injectable } from '@angular/core';

    export class ProductModel {
        id: number;
        title: string;
        description: string;
    }

    @Injectable({
        providedIn: 'root'
    })
    export class ProductsService {

        allProducts: Array<ProductModel>;

        constructor() {

            this.allProducts = [];
            let product = new ProductModel();
            product.id = 1;
            product.title = 'Product 1';
            product.description = 'Product 1 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 2;
            product.title = 'Product 2';
            product.description = 'Product 2 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 3;
            product.title = 'Product 3';
            product.description = 'Product 3 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 4;
            product.title = 'Product 4';
            product.description = 'Product 4 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 5;
            product.title = 'Product 5';
            product.description = 'Product 5 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 6;
            product.title = 'Product 6';
            product.description = 'Product 6 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 7;
            product.title = 'Product 7';
            product.description = 'Product 7 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 8;
            product.title = 'Product 8';
            product.description = 'Product 8 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 9;
            product.title = 'Product 9';
            product.description = 'Product 9 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 10;
            product.title = 'Product 10';
            product.description = 'Product 10 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 11;
            product.title = 'Product 11';
            product.description = 'Product 11 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 12;
            product.title = 'Product 12';
            product.description = 'Product 12 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 13;
            product.title = 'Product 13';
            product.description = 'Product 13 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 14;
            product.title = 'Product 14';
            product.description = 'Product 14 dummy description!';
            this.allProducts.push(product);

            product = new ProductModel();
            product.id = 15;
            product.title = 'Product 15';
            product.description = 'Product 15 dummy description!';
            this.allProducts.push(product);
        }

        getProduct(productId: number): ProductModel {
            const foundProduct = this.allProducts.findIndex(product => product.id === productId);
            return this.allProducts[foundProduct];
        }
    }

