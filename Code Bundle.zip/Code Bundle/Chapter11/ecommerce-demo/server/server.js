    const express = require('express')
    const app = express()
    const port = 9000

    app.get('/', (req, res) => res.send('Hello World!'))

    app.get('/users', (req, res) => {
        const users = [
            {
                "id": 1,
                "name": "user-1"
            },
            {
                "id": 2,
                "name": "user-2"
            },
            {
                "id": 3,
                "name": "user-3"
            }
        ]
        res.send(users)
    })

    app.listen(port, () => console.log(`Example app listening on port ${port}!`))