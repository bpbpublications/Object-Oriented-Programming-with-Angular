import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadingStrategy, PreloadAllModules, NoPreloading } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LoginModule } from './login/login.module';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignUpModule } from './sign-up/sign-up.module';
import { CustomPageNotFoundComponent } from './custom-page-not-found/custom-page-not-found.component';
import { DashboardModule } from './dashboard/dashboard.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProductsComponent } from './dashboard/products/products.component';
import { ProductsModule } from './dashboard/products/products.module';
import { ProductDetailsComponent } from './dashboard/products/product-details/product-details.component';
import { CanActivateDashboardGuard } from './dashboard.guard';
import { CanDeactivateDashboardGuard } from './can-deactivate-dashboard.guard';
import { ProductDetailsResolverService } from './product-details-resolver.service';


const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'sign-up',
        component: SignUpComponent
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [CanActivateDashboardGuard],
        canDeactivate: [CanDeactivateDashboardGuard],
        children: [
            {
                path: 'products',
                component: ProductsComponent
            },
            {
                path: 'products/:product-id',
                resolve: { selectedProduct: ProductDetailsResolverService },
                component: ProductDetailsComponent
            }
        ]
    },
    {
        path: 'my-account',
        loadChildren: () => import('./my-account/my-account.module')
            .then(m => m.MyAccountModule)
    },

    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full',
    },
    {
        path: '**',
        component: CustomPageNotFoundComponent
    }

];

@NgModule({
    imports: [
        LoginModule,
        SignUpModule,
        DashboardModule,
        ProductsModule,
        RouterModule.forRoot(
            routes,
            {
                enableTracing: false, // WARN: Disable it for production build
                // preloadingStrategy: NoPreloading
                preloadingStrategy: PreloadAllModules
            })
    ],
    exports: [RouterModule]
})
export class AppRoutingModule { }
