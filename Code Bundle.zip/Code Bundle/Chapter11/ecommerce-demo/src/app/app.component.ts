    import { Component, OnInit } from '@angular/core';
    import { environment } from 'src/environments/environment';
    import { HttpClient } from '@angular/common/http';

    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
    export class AppComponent implements OnInit {
        title = 'E-Commerce website';

        url = '/users';
        users = [];

        constructor(private http: HttpClient) { }

        ngOnInit() {
            const dummy = 100;
            // alert(`Access token: ${environment.accessToken}`);
            this.http.get(this.url).subscribe((users: JSON[]) => {
                this.users = users;
                console.log(users);
            });

            if (typeof Worker !== 'undefined') {
                // Create a new
                const worker = new Worker('./app.worker', { type: 'module' });
                worker.onmessage = ({ data }) => {
                    console.log(`Result: ${data}`);
                };
                worker.postMessage(25);
            } else {
                // Web Workers are not supported in this environment.
                // You should add a fallback so that your program still executes correctly.
            }
        }
    }




