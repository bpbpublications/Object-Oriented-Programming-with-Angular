    /// <reference lib="webworker" />

    addEventListener('message', ({ data }) => {
        const sqrt = Math.sqrt(data);
        const response = `Square root of ${data} is ${sqrt}`;
        postMessage(response);
    });

