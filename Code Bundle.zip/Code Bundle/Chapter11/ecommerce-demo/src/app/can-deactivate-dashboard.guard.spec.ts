
import { CanDeactivateDashboardGuard } from './can-deactivate-dashboard.guard';
import { DataService } from './data.service';


describe('DummyPipePipe', () => {
    it('create an instance', () => {
        const pipe = new CanDeactivateDashboardGuard(new DataService());
        expect(pipe).toBeTruthy();
    });
});
