    import { Injectable } from '@angular/core';
    import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanDeactivate, Router } from '@angular/router';
    import { DataService } from './data.service';

    @Injectable({
        providedIn: 'root'
    })
    export class CanDeactivateDashboardGuard implements CanDeactivate<boolean> {

        constructor(private dataService: DataService) { }

        canDeactivate(component: boolean,
                      currentRoute: ActivatedRouteSnapshot,
                      currentState: RouterStateSnapshot,
                      nextState?: RouterStateSnapshot): boolean {
            const response = window.confirm('Are you sure to Sign Out?');
            if (response) {
                this.dataService.signOut();
                return true;
            } else {
                return false;
            }
        }
    }
