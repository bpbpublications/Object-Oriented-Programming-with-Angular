import { TestBed, async, inject } from '@angular/core/testing';

import { CanActivateDashboardGuard } from './dashboard.guard';
import { DataService } from './data.service';
import { Router } from '@angular/router';

xdescribe('DashboardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CanActivateDashboardGuard, DataService, Router]
    });
  });

  it('should ...', inject([CanActivateDashboardGuard, DataService, Router], (guard: CanActivateDashboardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
