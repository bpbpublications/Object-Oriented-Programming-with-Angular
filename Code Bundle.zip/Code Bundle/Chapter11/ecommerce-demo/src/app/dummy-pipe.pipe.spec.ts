import { DummyPipePipe } from './dummy-pipe.pipe';

describe('DummyPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DummyPipePipe();
    expect(pipe).toBeTruthy();
  });
});
