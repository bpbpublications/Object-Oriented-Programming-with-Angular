import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dummyPipe'
})
export class DummyPipePipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
